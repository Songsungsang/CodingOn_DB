#include <iostream>
#include <windows.h>
#include <mysql/jdbc.h>
#include "book.h"
#include "member.h"
#include "rental.h"

using namespace std;

void showMenu() {
	cout << "\n==== Book Management System ====\n"
		<< "1. Register book    2. Book list    3. Edit book    4. Delete book" << endl
		<< "5. Register member    6. Member list    7. Edit member    8. Delete member" << endl
		<< "9. Rent book    10. Return book    11. Rent list" << endl
		<< "0. Exit" << endl
		<< "Choice: ";
}

int main() {
	SetConsoleCP(CP_UTF8);
	SetConsoleOutputCP(CP_UTF8);

	sql::mysql::MySQL_Driver* driver;
	unique_ptr<sql::Connection> con;

	try {
		driver = sql::mysql::get_mysql_driver_instance();
		con.reset(driver->connect("tcp://127.0.0.1:3306", "root", "3530"));
		con->setSchema("book_management_db");

		int choice;
		while (true) {
			showMenu();
			cin >> choice;

			switch (choice) {
				case 1: createBook(con); break;
				case 2: listBooks(con); break;
				case 3: updateBook(con); break;
				case 4: deleteBook(con); break;
				case 5: createMember(con); break;
				case 6: listMembers(con); break;
				case 7: updateMember(con); break;
				case 8: deleteMember(con); break;
				case 9: rentBook(con); break;
				case 10: returnBook(con);break;
				case 11: showRentalStatus(con);break;
				case 0: cout << "End program" << endl; return 0;
				default: cout << "Incorrect input" << endl; break;
			}
		}
	}
	catch (sql::SQLException& e) {
		cerr << "DB Connection failed: " << e.what() << endl;
	}
}