#pragma once

#include <mysql/jdbc.h>
#include <iostream>
using namespace std;

void createBook(unique_ptr<sql::Connection>& con);
void listBooks(unique_ptr<sql::Connection>& con);
void updateBook(unique_ptr<sql::Connection>& con);
void deleteBook(unique_ptr<sql::Connection>& con);