#pragma once

#include <mysql/jdbc.h>
#include <iostream>
using namespace std;

void rentBook(unique_ptr<sql::Connection>& con);
void returnBook(unique_ptr<sql::Connection>& con);
void showRentalStatus(unique_ptr<sql::Connection>& con);