#pragma once

#include <mysql/jdbc.h>
#include <iostream>
using namespace std;

void createMember(unique_ptr<sql::Connection>& con);
void listMembers(unique_ptr<sql::Connection>& con);
void updateMember(unique_ptr<sql::Connection>& con);
void deleteMember(unique_ptr<sql::Connection>& con);