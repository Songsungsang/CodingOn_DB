#include "rental.h"

void rentBook(unique_ptr<sql::Connection>& con) {
	int book_id, member_id;
	cout << "book id:";
	cin >> book_id;
	cout << "member id: ";
	cin >> member_id;
	
	try {
		unique_ptr<sql::PreparedStatement> checkStmt(
			con->prepareStatement("SELECT status FROM books WHERE book_id = ?")
		);
		checkStmt->setInt(1, book_id);
		unique_ptr<sql::ResultSet> res(checkStmt->executeQuery());

		if (!res->next()) {
			cout << "Book is not exists." << endl;
			return;
		}

		string status = res->getString("status");
		if (status == "ForRent") {
			cout << "Book is for rent." << endl;
			return;
		}

		unique_ptr<sql::PreparedStatement> insertStmt(
			con->prepareStatement("INSERT INTO rentals (book_id, member_id) VALUES (?,?)")
		);
		insertStmt->setInt(1, book_id);
		insertStmt->setInt(2, member_id);
		insertStmt->executeUpdate();

		unique_ptr<sql::PreparedStatement> updateStmt(
			con->prepareStatement("UPDATE books SET status = 'ForRent' WHERE book_id =?")
		);
		updateStmt->setInt(1, book_id);
		updateStmt->executeUpdate();

		cout << "Book rent complete" << endl;
	}
	catch (sql::SQLException& e) {
		cerr << "Rental error" << e.what() << endl;
	}
};
void returnBook(unique_ptr<sql::Connection>& con) {
	int book_id;
	cout << "[Book return] ID: ";
	cin >> book_id;
	try {
		unique_ptr<sql::PreparedStatement> selectStmt(
			con->prepareStatement("SELECT rental_id FROM rentals WHERE book_id = ? AND returned_at IS NULL")
		);
		selectStmt->setInt(1, book_id);
		unique_ptr<sql::ResultSet> res(selectStmt->executeQuery());

		if (!res->next()) {
			cout << "rental record is not exists" << endl;
			return;
		}

		int rental_id = res->getInt("rental_id");

		unique_ptr<sql::PreparedStatement> updateRental(
			con->prepareStatement("UPDATE rentals SET returned_at = NOW() WHERE rental_id = ?")
		);
		updateRental->setInt(1, rental_id);
		updateRental->executeUpdate();

		unique_ptr<sql::PreparedStatement> updateBook(
			con->prepareStatement("UPDATE books SET status = 'Available' WHERE book_id = ?")
		);
		updateBook->setInt(1, book_id);
		updateBook->executeUpdate();

		cout << "Book return complete!!" << endl;
	}
	catch (sql::SQLException& e) {
		cerr << "Return error" << e.what() << endl;
	}

};

void showRentalStatus(unique_ptr<sql::Connection>& con) {
	try {
		unique_ptr<sql::PreparedStatement> showStmt(
			con->prepareStatement(
				"SELECT r.rental_id, title, name, rented_at "
				"FROM rentals r "
				"JOIN books b ON r.book_id = b.book_id "
				"JOIN members m ON r.member_id = m.member_id "
				"WHERE r.returned_at IS NULL "
			)
		);

		unique_ptr<sql::ResultSet> res(showStmt->executeQuery());

		cout << "[Rental list]" << endl;
		while(res->next()){
			cout << "[" << res->getInt("rental_id") << "] "
				<< res->getString("title") << " | "
				<< res->getString("name") << " | "
				<< res->getString("rented_at") << endl;
 		}

	} catch (sql::SQLException& e) {
		cerr << "Return error" << e.what() << endl;
	}
};