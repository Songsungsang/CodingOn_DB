#include "book.h"

void createBook(unique_ptr<sql::Connection>& con) {
	string title, author, pub_date;
	int price;

	cin.ignore();
	cout << "[Book register]" << endl;
	cout << "Title: ";
	getline(cin, title);
	cout << "Author: ";
	getline(cin, author);
	cout << "Published date(yyyy-mm-dd): ";
	getline(cin, pub_date);
	cout << "Price: ";
	cin >> price;

	try {
		unique_ptr<sql::PreparedStatement> insertQuery(
			con->prepareStatement("INSERT INTO books (title, author, published_at, price) VALUES (?,?,?,?)")
		);

		insertQuery->setString(1, title);
		insertQuery->setString(2, author);
		insertQuery->setString(3, pub_date);
		insertQuery->setInt(4, price);
		insertQuery->executeQuery();
		cout << "Register complete" << endl;
	}
	catch (sql::SQLException& e) {
		cerr << "Register error" << e.what() << endl;
	}
};
void listBooks(unique_ptr<sql::Connection>& con) {
	try {
		unique_ptr<sql::PreparedStatement> selectStmt(
			con->prepareStatement("SELECT * FROM books")
		);
		unique_ptr<sql::ResultSet>res(selectStmt->executeQuery());

		cout << "[Book list]" << endl;
		while (res->next()) {
			cout << "[" << res->getInt("book_id") << "] "
				<< res->getString("title") << " | "
				<< res->getString("author") << " | "
				<< res->getString("published_at") << " | "
				<< res->getInt("price") << " | "
				<< res->getString("status") << endl;
		}
	}
	catch (sql::SQLException& e) {
		cerr << "Read error" << e.what() << endl;
	}

};
void updateBook(unique_ptr<sql::Connection>& con) {
	string title, author, pub_date;
	int book_id, price;

	cout << "[Book edit] id: " << endl;
	cin >> book_id;
	cin.ignore();
	cout << "Title: ";
	getline(cin, title);
	cout << "Author: ";
	getline(cin, author);
	cout << "Published date(yyyy-mm-dd): ";
	getline(cin, pub_date);
	cout << "Price: ";
	cin >> price;

	try {
		unique_ptr<sql::PreparedStatement> updateQuery(
			con->prepareStatement("UPDATE books SET title=?, author=?, published_at=?, price=? WHERE book_id=?")
		);

		updateQuery->setString(1, title);
		updateQuery->setString(2, author);
		updateQuery->setString(3, pub_date);
		updateQuery->setInt(4, price);
		updateQuery->setInt(5, book_id);
		int result = updateQuery->executeUpdate();
		cout << "Update complete" << endl;
	}
	catch (sql::SQLException& e) {
		cerr << "Update error" << e.what() << endl;
	}
};
void deleteBook(unique_ptr<sql::Connection>& con) {
	int book_id;
	cout << "[Delete book] id:";
	cin >> book_id;

	try {
		unique_ptr<sql::PreparedStatement> deleteQuery(
			con->prepareStatement("DELETE FROM books WHERE book_id =?")
		);

		deleteQuery->setInt(1, book_id);
		deleteQuery->executeQuery();
		cout << "Delete complete" << endl;
	}
	catch (sql::SQLException& e) {
		cerr << "Delete error" << e.what() << endl;
	}
};