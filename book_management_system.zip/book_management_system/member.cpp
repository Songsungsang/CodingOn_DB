#include "member.h"

void createMember(unique_ptr<sql::Connection>& con) {
    string name, email, phone;
    cin.ignore();
    cout << "[Member register]\nname: ";
    getline(std::cin, name);
    cout << "Email: ";
    getline(std::cin, email);
    cout << "Phone number: ";
    getline(std::cin, phone);

    try {
        unique_ptr<sql::PreparedStatement> pstmt(
            con->prepareStatement("INSERT INTO members (name, email, phone) VALUES (?, ?, ?)")
        );
        pstmt->setString(1, name);
        pstmt->setString(2, email);
        pstmt->setString(3, phone);
        pstmt->executeUpdate();
        cout << "Member Register complete" << endl;
    }
    catch (sql::SQLException& e) {
        cerr << "ȸ�� ��� ����: " << e.what() << endl;
    }
}

void listMembers(unique_ptr<sql::Connection>& con) {
    try {
        unique_ptr<sql::PreparedStatement> pstmt(
            con->prepareStatement("SELECT * FROM members")
        );
        unique_ptr<sql::ResultSet> res(pstmt->executeQuery());

        cout << "[Member list]\n";
        while (res->next()) {
            std::cout << "[" << res->getInt("member_id") << "] "
                << res->getString("name") << " | "
                << res->getString("email") << " | "
                << res->getString("phone") << endl;
        }
    }
    catch (sql::SQLException& e) {
        cerr << "Read error: " << e.what() << endl;
    }
}

void updateMember(unique_ptr<sql::Connection>& con) {
    int member_id;
    std::string name, email, phone;

    std::cout << "[Book edit] ID: ";
    std::cin >> member_id;
    std::cin.ignore();
    std::cout << "Name: ";
    std::getline(std::cin, name);
    std::cout << "Email: ";
    std::getline(std::cin, email);
    std::cout << "Phone number: ";
    std::getline(std::cin, phone);

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            con->prepareStatement("UPDATE members SET name=?, email=?, phone=? WHERE member_id=?")
        );
        pstmt->setString(1, name);
        pstmt->setString(2, email);
        pstmt->setString(3, phone);
        pstmt->setInt(4, member_id);
        int result = pstmt->executeUpdate();
        cout << "Update complete" << endl;
    }
    catch (sql::SQLException& e) {
        cerr << "Update error: " << e.what() << endl;
    }
}

void deleteMember(unique_ptr<sql::Connection>& con) {
    int member_id;
    cout << "Delete member ID: ";
    cin >> member_id;

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            con->prepareStatement("DELETE FROM members WHERE member_id = ?")
        );
        pstmt->setInt(1, member_id);
        int result = pstmt->executeUpdate();
        cout << "Delete complete" << endl;
    }
    catch (sql::SQLException& e) {
        std::cerr << "Delete error: " << e.what() << std::endl;
    }
}
